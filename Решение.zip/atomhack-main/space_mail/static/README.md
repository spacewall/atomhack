Folder for static files such as images, css, etc.
